!-------Begin README Template--------------!

====================
Maria A Yala
Drexel User Id: may36
Assignment #1
====================

--------------------
Java Version : JavaSE-1.7
--------------------

--------------------
Running It
--------------------
To run Program1 ---------- "java -jar Program1.jar"
To run Program2 ---------- "java -jar Program2.jar"
To run Program3 ---------- "java -jar Program3.jar"


--------------------
What Works
--------------------
Program 2 & Program 3 both work

--------------------
What doesn't
--------------------
In program1.java, the "Help, OK, Advanced & Cancel"
buttons do not resize with the window as instructed but
everything else works.

could not run my program on tux, kept getting the following error.

"no x11 variable was set" and "can't connect to X11 window server using "0.0" as the value of the DISPLAY variable"
 but the jar files run in the terminal off tux and I have also included my eclipse projects. 
---------------------
Notes
---------------------
I exported my projects from eclipse to create runnable jars which I included in the submission. I also included my eclipse project just incase I exported wrong.

!!------------End README Template-----------!!


